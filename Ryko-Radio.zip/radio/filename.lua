-- This is a snippet of the bridge logic for ESX
if GetResourceState('es_extended') == 'started' then
    local ESX = exports['es_extended']:getSharedObject()
    
    function GetPlayerJob(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        return xPlayer and xPlayer.job.name or 'unemployed'
    end

    function HasRadioItem(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        local item = xPlayer.getInventoryItem('radio')
        return item and item.count > 0
    end
end
## Introduction
**Ryko Radio** is simple radio UI for pma-voice.


## Dependencies
- [pma-voice](https://github.com/AvarianKnight/pma-voice)
- [ox_lib](https://github.com/communityox/ox_lib)
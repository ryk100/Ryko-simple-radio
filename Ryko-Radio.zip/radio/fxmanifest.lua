fx_version "cerulean"
game "gta5"

author "Ryk100"
description "Advanced Radio System"
version "1.0.1"

ui_page "html/ui.html"

files {
    "html/ui.html",
    "html/style.css",
    "html/script.js",
    "html/sounds/click.ogg",
    "html/sounds/power_on.ogg",
    "html/sounds/power_off.ogg",
    "html/sounds/mic_on.ogg",
    "html/sounds/mic_off.ogg"
}

shared_scripts {
    "@ox_lib/init.lua",
    "config/main.lua"
}

client_scripts {
    "client/util.lua",
    "client/main.lua"
}

server_scripts {
    "@oxmysql/lib/MySQL.lua",
    "server/main.lua"
}

dependencies {
    "ox_lib",
    "es_extended",
    "pma-voice"
}
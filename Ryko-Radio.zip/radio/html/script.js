let currentInput = "";
let isPowerOn = false;
let currentBattery = 100;
let audioUnlocked = false;

/**
 * Browsers block audio until the user interacts with the page.
 * This function "wakes up" the audio context on the first click/interaction.
 */
function unlockAudio() {
    if (audioUnlocked) return;
    
    const silentAudio = document.getElementById("audio-click");
    if (silentAudio) {
        silentAudio.play().then(() => {
            silentAudio.pause();
            silentAudio.currentTime = 0;
            audioUnlocked = true;
            console.log("Audio Context Unlocked");
        }).catch(e => console.error("Audio unlock failed:", e));
    }
}

function playSound(fileName, volume = 0.4) {
    let audioId = "";
    switch(fileName) {
        case "click.ogg": audioId = "audio-click"; break;
        case "power_on.ogg": audioId = "audio-power-on"; break;
        case "power_off.ogg": audioId = "audio-power-off"; break;
        case "mic_on.ogg": audioId = "audio-mic-on"; break;
        case "mic_off.ogg": audioId = "audio-mic-off"; break;
        default:
            const audio = new Audio(`./sounds/${fileName}`);
            audio.volume = volume;
            audio.play().catch(() => {});
            return;
    }

    const el = document.getElementById(audioId);
    if (el) {
        el.currentTime = 0;
        el.volume = volume;
        el.play().catch(err => {
            console.warn("Playback blocked. Waiting for user interaction.", err);
        });
    }
}

window.addEventListener("message", function(event) {
    const data = event.data;

    if (data.action === "setVisible") {
        if (data.data) {
            document.body.classList.add("visible");
            currentBattery = data.battery;
            updateBatteryDisplay();
            updateClock();
        } else {
            document.body.classList.remove("visible");
        }
    }

    if (data.action === "audio") {
        playSound(data.file, data.volume || 0.4);
    }

    if (data.action === "updateBattery") {
        currentBattery = data.battery;
        updateBatteryDisplay();
    }

    if (data.action === "forceOff") {
        if (isPowerOn) {
            forcePowerOff();
        }
    }
});

function updateClock() {
    const now = new Date();
    const timeStr = now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true });
    const clockEl = document.getElementById("clock");
    if (clockEl) clockEl.innerText = timeStr;
}

function updateBatteryDisplay() {
    const bar = document.getElementById("battery-bar");
    if (!bar) return;
    bar.style.width = `${currentBattery}%`;
    
    if (currentBattery < 15) {
        bar.style.backgroundColor = "#d32f2f";
    } else if (currentBattery < 40) {
        bar.style.backgroundColor = "#fbc02d";
    } else {
        bar.style.backgroundColor = "#2e7d32";
    }
}

function togglePower() {
    unlockAudio(); // Ensure audio is unlocked on first interaction
    isPowerOn = !isPowerOn;
    
    if (isPowerOn) {
        if (currentBattery <= 0) {
            isPowerOn = false;
            playSound("click.ogg", 0.5);
            return;
        }
        document.body.classList.add("on");
        playSound("power_on.ogg", 0.5);
        document.getElementById("status-text").innerText = "CONNECTING...";
        setTimeout(() => {
            if (isPowerOn) document.getElementById("status-text").innerText = "NETWORK READY";
        }, 1500);
    } else {
        document.body.classList.remove("on");
        playSound("power_off.ogg", 0.5);
        currentInput = "";
    }

    fetch(`https://${GetParentResourceName()}/togglePower`, {
        method: "POST",
        body: JSON.stringify({ power: isPowerOn })
    });
    
    updateDisplay();
}

function forcePowerOff() {
    isPowerOn = false;
    document.body.classList.remove("on");
    playSound("power_off.ogg", 0.5);
    currentInput = "";
    updateDisplay();
}

function pressKey(num) {
    unlockAudio();
    if (!isPowerOn) return;
    if (currentInput.length >= 6) return;
    
    currentInput += num;
    playSound("click.ogg", 0.15);
    updateDisplay();
}

function clearFreq() {
    unlockAudio();
    if (!isPowerOn) return;
    currentInput = "";
    playSound("click.ogg", 0.2);
    updateDisplay();
}

function updateDisplay() {
    const display = document.getElementById("freq-display");
    if (!isPowerOn) {
        display.innerText = "OFFLINE";
        return;
    }
    
    if (currentInput.length === 0) {
        display.innerText = "000.0";
    } else {
        display.innerText = currentInput;
    }
}

function submitFreq() {
    unlockAudio();
    if (!isPowerOn || currentInput === "") return;
    
    playSound("click.ogg", 0.4);
    document.getElementById("status-text").innerText = "TRANSMITTING...";
    
    fetch(`https://${GetParentResourceName()}/setFrequency`, {
        method: "POST",
        body: JSON.stringify({ frequency: currentInput })
    });

    setTimeout(() => {
        if (isPowerOn) document.getElementById("status-text").innerText = "LINK ESTABLISHED";
    }, 1000);
}

function adjustFreq(amt) {
    unlockAudio();
    if (!isPowerOn) return;
    let val = parseFloat(currentInput) || 0;
    val = (parseFloat(val) + amt).toFixed(1);
    if (val < 0) val = 0;
    currentInput = val.toString();
    playSound("click.ogg", 0.1);
    updateDisplay();
}

document.onkeydown = function(data) {
    if (data.key === "Escape") {
        fetch(`https://${GetParentResourceName()}/close`, {
            method: "POST",
            body: JSON.stringify({})
        });
    } else if (!isNaN(data.key)) {
        pressKey(data.key);
    } else if (data.key === "Enter") {
        submitFreq();
    } else if (data.key === "Backspace") {
        currentInput = currentInput.slice(0, -1);
        playSound("click.ogg", 0.1);
        updateDisplay();
    }
};

// Start clock
setInterval(updateClock, 10000);
updateClock();
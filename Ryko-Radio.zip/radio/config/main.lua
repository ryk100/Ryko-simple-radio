Config = {}

Config.MaxFrequency = 500.0
Config.MinFrequency = 1.0

-- Frequencies restricted to specific jobs
Config.RestrictedChannels = {
    [1] = { jobs = {"police", "sheriff"}, label = "LSPD Primary" },
    [2] = { jobs = {"police", "sheriff"}, label = "LSPD Secondary" },
    [3] = { jobs = {"ambulance"}, label = "EMS Main" },
    [4] = { jobs = {"ambulance", "police"}, label = "Emergency Tactical" },
}

Config.Battery = {
    Enabled = true,
    DrainRate = 0.2, -- Percent drained per minute while radio is ON
    TalkDrain = 0.05, -- Extra drain per second while talking
}

Config.Items = {
    Radio = "radio"
}

Config.Sounds = {
    Click = "click.ogg",
    PowerOn = "power_on.ogg",
    PowerOff = "power_off.ogg",
    MicClickOn = "mic_on.ogg",
    MicClickOff = "mic_off.ogg"
}
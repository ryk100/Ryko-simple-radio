local function playRadioAnim()
    local ped = PlayerPedId()
    lib.requestAnimDict("random@arrests")
    TaskPlayAnim(ped, "random@arrests", "generic_radio_chatter", 8.0, 0.0, -1, 49, 0, false, false, false)
end

local function stopRadioAnim()
    local ped = PlayerPedId()
    StopAnimTask(ped, "random@arrests", "generic_radio_chatter", 1.0)
end

function ToggleRadioAnimation(status)
    if status then
        playRadioAnim()
    else
        stopRadioAnim()
    end
end
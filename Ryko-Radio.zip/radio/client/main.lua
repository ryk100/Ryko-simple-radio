local ESX = exports["es_extended"]:getSharedObject()
local isRadioOpen = false
local currentChannel = 0
local isRadioOn = false
local isTalking = false
local batteryLevel = 100.0

-- Open/Close Radio UI
local function toggleRadioUI(status)
    isRadioOpen = status
    SetNuiFocus(status, status)
    SendNUIMessage({
        action = "setVisible",
        data = status,
        battery = math.floor(batteryLevel)
    })
end

-- Handle Radio Logic
local function joinChannel(channel)
    if channel == currentChannel then return end
    
    if currentChannel ~= 0 then
        exports["pma-voice"]:setRadioChannel(0)
    end

    currentChannel = channel
    if channel > 0 then
        exports["pma-voice"]:setRadioChannel(channel)
        lib.notify({
            title = "Radio",
            description = "Joined frequency: " .. channel .. " MHz",
            type = "success"
        })
    end
end

-- Events
RegisterNetEvent("ars:client:openRadio", function()
    ESX.TriggerServerCallback("ars:server:hasRadio", function(hasItem, savedBattery)
        if hasItem then
            if savedBattery then batteryLevel = savedBattery end
            toggleRadioUI(not isRadioOpen)
        else
            lib.notify({ title = "Error", description = "You do not have a radio", type = "error" })
        end
    end)
end)

-- NUI Callbacks
RegisterNUICallback("close", function(data, cb)
    toggleRadioUI(false)
    cb("ok")
end)

RegisterNUICallback("togglePower", function(data, cb)
    if batteryLevel <= 0 and data.power then 
        lib.notify({title = "Radio", description = "Battery dead", type = "error"})
        return cb("ok") 
    end

    isRadioOn = data.power
    if not isRadioOn then
        joinChannel(0)
    end
    cb("ok")
end)

RegisterNUICallback("setFrequency", function(data, cb)
    local freq = tonumber(data.frequency)
    if freq then
        if freq > Config.MaxFrequency or freq < Config.MinFrequency then
            lib.notify({title = "Invalid Freq", description = "Frequency out of range", type = "error"})
            return cb("ok")
        end

        ESX.TriggerServerCallback("ars:server:canJoinChannel", function(canJoin)
            if canJoin then
                joinChannel(freq)
            else
                lib.notify({
                    title = "Access Denied",
                    description = "This frequency is encrypted.",
                    type = "error"
                })
            end
        end, freq)
    end
    cb("ok")
end)

-- Battery & Interaction Loop
CreateThread(function()
    while true do
        local sleep = 1000
        if isRadioOn then
            sleep = 5000 
            local drain = (Config.Battery.DrainRate / 12) 
            
            if isTalking then
                drain = drain + (Config.Battery.TalkDrain * 5)
            end

            batteryLevel = math.max(0.0, batteryLevel - drain)

            if batteryLevel <= 0 then
                isRadioOn = false
                joinChannel(0)
                SendNUIMessage({ action = "forceOff" })
                TriggerServerEvent("ars:server:saveBattery", 0)
                lib.notify({title = "Radio", description = "Battery depleted", type = "error"})
            end

            if isRadioOpen then
                SendNUIMessage({ action = "updateBattery", battery = math.floor(batteryLevel) })
            end
        end
        Wait(sleep)
    end
end)

-- Handle Talking Animation & Mic Clicks
CreateThread(function()
    while true do
        local sleep = 500
        if isRadioOn and currentChannel > 0 then
            sleep = 100
            local talking = exports["pma-voice"]:getRadioTalkingState()
            if talking and not isTalking then
                isTalking = true
                ToggleRadioAnimation(true)
                SendNUIMessage({ action = "audio", file = Config.Sounds.MicClickOn, volume = 0.3 })
            elseif not talking and isTalking then
                isTalking = false
                ToggleRadioAnimation(false)
                SendNUIMessage({ action = "audio", file = Config.Sounds.MicClickOff, volume = 0.3 })
            end
        end
        Wait(sleep)
    end
end)

-- Save battery level on resource stop
AddEventHandler("onResourceStop", function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    TriggerServerEvent("ars:server:saveBattery", batteryLevel)
end)
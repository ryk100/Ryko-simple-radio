local ESX = exports["es_extended"]:getSharedObject()

-- Database Initialization
MySQL.ready(function()
    MySQL.query.await([[
        CREATE TABLE IF NOT EXISTS player_radio_settings (
            identifier VARCHAR(60) NOT NULL,
            battery INT DEFAULT 100,
            PRIMARY KEY (identifier)
        )
    ]])
end)

-- Register Usable Item
ESX.RegisterUsableItem(Config.Items.Radio, function(source)
    TriggerClientEvent("ars:client:openRadio", source)
end)

-- Check if player has radio item and fetch battery
ESX.RegisterServerCallback("ars:server:hasRadio", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return cb(false) end
    
    local item = xPlayer.getInventoryItem(Config.Items.Radio)
    if not (item and item.count > 0) then 
        return cb(false) 
    end

    local result = MySQL.single.await("SELECT battery FROM player_radio_settings WHERE identifier = ?", {xPlayer.identifier})
    cb(true, result and result.battery or 100)
end)

-- Check channel permissions
ESX.RegisterServerCallback("ars:server:canJoinChannel", function(source, cb, channel)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return cb(false) end

    local restriction = Config.RestrictedChannels[channel]
    if not restriction then return cb(true) end

    local playerJob = xPlayer.job.name
    local isAuthorized = false

    for _, job in ipairs(restriction.jobs) do
        if job == playerJob then
            isAuthorized = true
            break
        end
    end

    cb(isAuthorized)
end)

-- Save Battery Level
RegisterNetEvent("ars:server:saveBattery", function(level)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return end

    MySQL.update.await("INSERT INTO player_radio_settings (identifier, battery) VALUES (?, ?) ON DUPLICATE KEY UPDATE battery = ?", {
        xPlayer.identifier, math.floor(level), math.floor(level)
    })
end)